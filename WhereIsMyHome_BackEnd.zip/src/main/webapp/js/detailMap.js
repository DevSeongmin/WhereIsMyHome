function detailMarker(lat, lng, content){
	
	var infowindow = new kakao.maps.InfoWindow({ zIndex: 1 });
	var ps = new kakao.maps.services.Places();


	var mapContainer = document.getElementById("map"); // 지도를 표시할 div
	mapOption = {
	  center: new kakao.maps.LatLng(36.355116, 127.298372), // 지도의 중심좌표
	  level: 5, // 지도의 확대 레벨
	};
	var map = new kakao.maps.Map(mapContainer, mapOption);
    // 마커가 표시될 위치입니다 
    var markerPosition  = new kakao.maps.LatLng(lat, lng); 

    // 마커를 생성합니다
    var marker = new kakao.maps.Marker({
        position: markerPosition,
    });

    // 마커가 지도 위에 표시되도록 설정합니다
    marker.setMap(map);
    map.setCenter(markerPosition);

    
    
    // 마커에 커서가 오버됐을 때 마커 위에 표시할 인포윈도우를 생성합니다
       var iwContent = `<div style="padding:5px;">${content}</div>`; // 인포윈도우에 표출될 내용으로 HTML 문자열이나 document element가 가능합니다

       // 인포윈도우를 생성합니다
       var infowindow = new kakao.maps.InfoWindow({
           content : iwContent
       });

       // 마커에 마우스오버 이벤트를 등록합니다
       kakao.maps.event.addListener(marker, 'mouseover', function() {
         // 마커에 마우스오버 이벤트가 발생하면 인포윈도우를 마커위에 표시합니다
           infowindow.open(map, marker);
       });

       // 마커에 마우스아웃 이벤트를 등록합니다
       kakao.maps.event.addListener(marker, 'mouseout', function() {
           // 마커에 마우스아웃 이벤트가 발생하면 인포윈도우를 제거합니다
           infowindow.close();
       });
       
       
    
}